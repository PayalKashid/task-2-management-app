from datetime import datetime

def project_helper(project) -> dict:
    return {
        "id": str(project["_id"]),
        "name": project["name"],
        "description": project.get("description"),
        "created_at": project["created_at"],
        "user_id": project["user_id"]
    }