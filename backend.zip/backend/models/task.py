def task_helper(task) -> dict:
    return {
        "id": str(task["_id"]),
        "title": task["title"],
        "description": task.get("description"),
        "status": task["status"],
        "priority": task["priority"],
        "due_date": task.get("due_date"),
        "created_at": task["created_at"],
        "updated_at": task["updated_at"],
        "project_id": task["project_id"]
    }