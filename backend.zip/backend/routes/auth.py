from fastapi import APIRouter, HTTPException, Depends
from passlib.context import CryptContext
from datetime import datetime, timedelta
import jwt

from database import users_collection
from schemas.user_schema import UserRegister, UserLogin, Token

router = APIRouter(prefix="/auth", tags=["Auth"])

# --------------------
# CONFIG
# --------------------
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


# --------------------
# HASH PASSWORD
# --------------------
def hash_password(password: str):
    return pwd_context.hash(password)


# --------------------
# VERIFY PASSWORD
# --------------------
def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)


# --------------------
# CREATE TOKEN
# --------------------
def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


# --------------------
# REGISTER
# --------------------
@router.post("/register")
async def register(user: UserRegister):
    existing = await users_collection.find_one({"email": user.email})
    if existing:
        raise HTTPException(status_code=400, detail="User already exists")

    user_data = {
        "name": user.name,
        "email": user.email,
        "password": hash_password(user.password),
        "created_at": datetime.utcnow()
    }

    result = await users_collection.insert_one(user_data)

    return {"message": "User registered successfully"}


# --------------------
# LOGIN
# --------------------
@router.post("/login", response_model=Token)
async def login(user: UserLogin):
    db_user = await users_collection.find_one({"email": user.email})

    if not db_user:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    token = create_access_token({"user_id": str(db_user["_id"])})

    return {
        "access_token": token,
        "token_type": "bearer"
    }


# --------------------
# GET CURRENT USER
# --------------------
@router.get("/me")
async def get_me():
    return {"message": "Add JWT dependency later (next step)"}