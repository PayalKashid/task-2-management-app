from fastapi import APIRouter, Depends, HTTPException, Query
from bson import ObjectId
from datetime import datetime

from database import tasks_collection, projects_collection
from schemas.task import TaskCreate, TaskUpdate, TaskStatusUpdate
from models.task import task_helper
from utils.auth import get_current_user

router = APIRouter(prefix="/tasks", tags=["Tasks"])


# --------------------
# CREATE TASK (UNDER PROJECT)
# --------------------
@router.post("/projects/{project_id}/tasks")
async def create_task(
    project_id: str,
    task: TaskCreate,
    user_id: str = Depends(get_current_user)
):
    project = await projects_collection.find_one({
        "_id": ObjectId(project_id),
        "user_id": user_id
    })

    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    new_task = {
        "title": task.title,
        "description": task.description,
        "status": "Pending",
        "priority": task.priority,
        "due_date": task.due_date,
        "project_id": project_id,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow()
    }

    result = await tasks_collection.insert_one(new_task)
    created_task = await tasks_collection.find_one({"_id": result.inserted_id})

    return task_helper(created_task)


# --------------------
# GET TASKS (FILTER + PAGINATION)
# --------------------
@router.get("")
async def get_tasks(
    status: str = None,
    priority: str = None,
    skip: int = 0,
    limit: int = 10,
    sort_by: str = None,
    user_id: str = Depends(get_current_user)
):

    projects = projects_collection.find({"user_id": user_id})
    project_ids = [str(p["_id"]) async for p in projects]

    query = {"project_id": {"$in": project_ids}}

    if status:
        query["status"] = status

    if priority:
        query["priority"] = priority

    cursor = tasks_collection.find(query)

    if sort_by == "due_date":
        cursor = cursor.sort("due_date", 1)

    cursor = cursor.skip(skip).limit(limit)

    tasks = []

    async for task in cursor:
        tasks.append(task_helper(task))

    return tasks


# --------------------
# GET TASK BY ID
# --------------------
@router.get("/{task_id}")
async def get_task(task_id: str, user_id: str = Depends(get_current_user)):
    task = await tasks_collection.find_one({"_id": ObjectId(task_id)})

    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    return task_helper(task)


# --------------------
# UPDATE TASK
# --------------------
@router.put("/{task_id}")
async def update_task(
    task_id: str,
    task: TaskUpdate,
    user_id: str = Depends(get_current_user)
):

    update_data = {k: v for k, v in task.dict().items() if v is not None}
    update_data["updated_at"] = datetime.utcnow()

    result = await tasks_collection.update_one(
        {"_id": ObjectId(task_id)},
        {"$set": update_data}
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")

    updated_task = await tasks_collection.find_one({"_id": ObjectId(task_id)})
    return task_helper(updated_task)


# --------------------
# DELETE TASK
# --------------------
@router.delete("/{task_id}")
async def delete_task(task_id: str, user_id: str = Depends(get_current_user)):

    result = await tasks_collection.delete_one({"_id": ObjectId(task_id)})

    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")

    return {"message": "Task deleted successfully"}


# --------------------
# PATCH STATUS ONLY
# --------------------
@router.patch("/{task_id}/status")
async def update_status(
    task_id: str,
    status_update: TaskStatusUpdate,
    user_id: str = Depends(get_current_user)
):

    result = await tasks_collection.update_one(
        {"_id": ObjectId(task_id)},
        {
            "$set": {
                "status": status_update.status,
                "updated_at": datetime.utcnow()
            }
        }
    )

    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Task not found")

    task = await tasks_collection.find_one({"_id": ObjectId(task_id)})
    return task_helper(task)